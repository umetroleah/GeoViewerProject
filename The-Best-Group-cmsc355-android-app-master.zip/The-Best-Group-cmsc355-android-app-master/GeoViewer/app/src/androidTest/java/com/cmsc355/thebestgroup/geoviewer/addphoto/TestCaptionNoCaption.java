package com.cmsc355.thebestgroup.geoviewer.addphoto;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.intent.Intents.intending;
import static android.support.test.espresso.intent.matcher.IntentMatchers.hasAction;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.isEnabled;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.test.espresso.intent.rule.IntentsTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.cmsc355.thebestgroup.geoviewer.R;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//test for Captions user story, No_Caption scenario

@RunWith(AndroidJUnit4.class)
public class TestCaptionNoCaption {

    @Rule
    public IntentsTestRule<AddPhotoToDatabaseActivity> myIntentsRule
            = new IntentsTestRule<>(AddPhotoToDatabaseActivity.class);


    @Before
    public void stubCameraIntent() {
        Instrumentation.ActivityResult result = createImageCaptureActivityResultStub();

        intending(hasAction(MediaStore.ACTION_IMAGE_CAPTURE)).respondWith(result);
    }

    @Test
    public void testPhotoTaken() {

        onView(withId(R.id.cameraButton)).perform(click());

        onView(withId(R.id.photoImageView)).check(matches(isDisplayed()));
        onView(withId(R.id.submitButton)).check(matches(isEnabled()));
        onView(withId(R.id.captionText)).check(matches(isEnabled()));

        onView(withId(R.id.captionText)).check(matches(withText("")));

    }


    private Instrumentation.ActivityResult createImageCaptureActivityResultStub() {
        //put the image in a bundle

        Bundle bundle = new Bundle();
        bundle.putParcelable("data",
                BitmapFactory.decodeResource(myIntentsRule.getActivity().getResources(),
                        R.drawable.test_image));

        Intent resultData = new Intent();
        resultData.putExtras(bundle);

        return new Instrumentation.ActivityResult(Activity.RESULT_OK, resultData);
    }

}