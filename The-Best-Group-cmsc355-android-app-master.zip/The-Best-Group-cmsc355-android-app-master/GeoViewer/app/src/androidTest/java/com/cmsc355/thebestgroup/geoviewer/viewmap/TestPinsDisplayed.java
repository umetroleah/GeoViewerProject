package com.cmsc355.thebestgroup.geoviewer.viewmap;

import android.location.LocationManager;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;


import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;


//tests View map centered on me user story, Photo_Pins_Displays scenario

@RunWith(AndroidJUnit4.class)
public class TestPinsDisplayed {

    @Rule
    public ActivityTestRule<MapsActivity> myActivityTestRule
            = new ActivityTestRule<>(MapsActivity.class);

    @Test
    public void lostSignalError() {
        MockLocationProvider mock = new MockLocationProvider(LocationManager.GPS_PROVIDER,
                myActivityTestRule.getActivity() );

    }
}
