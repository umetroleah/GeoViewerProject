package com.cmsc355.thebestgroup.geoviewer.unittests;

import android.content.Context;

import com.cmsc355.thebestgroup.geoviewer.viewmap.MapsActivity;

import org.junit.Test;
import org.mockito.Mock;


public class UnitTestsTdd2 {

    @Mock
    Context myMockContext;

    @Test
    public void test_MapsActivity_isNetworkStatusAvailable_testReturnsTrue() {
        assert (MapsActivity.isNetworkStatusAvialable(myMockContext) == true);
    }

    @Test
    public void test_MapsActivity_isNetworkStatusAvailable_testReturnsFalse() {
        assert (MapsActivity.isNetworkStatusAvialable(myMockContext) == false);
    }

}
