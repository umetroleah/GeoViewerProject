package com.cmsc355.thebestgroup.geoviewer.signin;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.cmsc355.thebestgroup.geoviewer.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//test for Logout user story, Settings_Logout scenario

@RunWith(AndroidJUnit4.class)
public class TestNoInternet {


    @Rule
    public ActivityTestRule<SignInActivity> myActivityTestRule
            = new ActivityTestRule<>(SignInActivity.class);

    @Test
    public void lostSignalError() {

        Context context = myActivityTestRule.getActivity();
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        wifiManager.setWifiEnabled(false);

        //Turn off mobile data manually, since phone has to be rooted to turn off data through code

        onView(withId(R.id.g_login_button)).perform(click());

        //Wait a certain amount on time for error message to appear
        final long start = System.currentTimeMillis();
        long end = System.currentTimeMillis();
        while (end - start < 2000) {
            end = System.currentTimeMillis();
        }

        onView(withText("Ok")).check(matches(isDisplayed()));
    }
}
