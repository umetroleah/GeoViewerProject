package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

import android.support.test.rule.ActivityTestRule;

import com.amazonaws.mobile.AWSMobileClient;
import com.amazonaws.models.nosql.PinsDO;
import com.cmsc355.thebestgroup.geoviewer.viewmap.MapsActivity;

import org.junit.Rule;
import org.junit.Test;


//tests the Database Service Iteration 2 user story, AsyncNearbyPins scenario

//tests the download object list function by downloading an object list and waiting on a response
//the debug log details waiting on the thread to finish
public class TestNearbyPins implements AsyncNearbyPinsResponse {

    @Rule
    public ActivityTestRule<MapsActivity> myActivityTestRule = new
            ActivityTestRule<>(MapsActivity.class);

    @Test
    public void testNearbyPins() {
        AWSMobileClient.initializeMobileClientIfNecessary(myActivityTestRule.getActivity());
        AsyncNearbyPins pins = new AsyncNearbyPins();
        pins.delegate = this;
        pins.execute(0.0,11000.00,0.0,11000.00);
    }

    @Override
    public void pinsDownloaded(PinsDO[] pins) {
        PinsDO[] test = pins;
    }
}
