package com.cmsc355.thebestgroup.geoviewer.viewphoto;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isEnabled;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static org.mockito.AdditionalMatchers.not;

import android.location.LocationManager;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.cmsc355.thebestgroup.geoviewer.R;
import com.cmsc355.thebestgroup.geoviewer.viewmap.MapsActivity;
import com.cmsc355.thebestgroup.geoviewer.viewmap.MockLocationProvider;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//Test for Visit_Photo_Button

@RunWith(AndroidJUnit4.class)
public class TestVisitPhotoButtonDisable {

    @Rule
    public ActivityTestRule<MapsActivity> mapsActivityTestRule
            = new ActivityTestRule<>(MapsActivity.class);

    @Test
    public void testAddPhotoButtonDisable() {
        MockLocationProvider mock = new MockLocationProvider(LocationManager.GPS_PROVIDER,
                mapsActivityTestRule.getActivity() );
        mock.pushLocation(-77.4542, 37.5477);
        mock.shutdown();

        try {
            wait(2000);
        } catch (Exception exception) {
            return;
        }

        onView(withId(R.id.viewPhotoButton)).check(matches(isEnabled()));

        mock = new MockLocationProvider(LocationManager.GPS_PROVIDER,
                mapsActivityTestRule.getActivity() );
        mock.pushLocation(0, 0);
        mock.shutdown();

        try {
            wait(2000);
        } catch (Exception exception) {
            return;
        }

        onView(withId(R.id.viewPhotoButton)).check(not(matches(isEnabled())));
    }

}
