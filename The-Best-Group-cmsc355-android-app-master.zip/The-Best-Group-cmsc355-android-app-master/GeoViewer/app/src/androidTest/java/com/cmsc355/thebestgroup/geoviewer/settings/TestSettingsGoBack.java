package com.cmsc355.thebestgroup.geoviewer.settings;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.cmsc355.thebestgroup.geoviewer.R;
import com.cmsc355.thebestgroup.geoviewer.viewmap.MapsActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//test for Logout user story, Settings_Go_Back scenario


@RunWith(AndroidJUnit4.class)
public class TestSettingsGoBack {

    @Rule
    public ActivityTestRule<MapsActivity> mapsActivityTestRule
            = new ActivityTestRule<>(MapsActivity.class);

    @Test
    public void testAddPhotoGoBack() {
        onView(withId(R.id.settingsButton)).perform(click());
        onView(withId(R.id.activity_settings)).check(matches(isDisplayed()));

        pressBack();
        onView(withId(R.id.map_activity_layout)).check(matches(isDisplayed()));

    }

}
