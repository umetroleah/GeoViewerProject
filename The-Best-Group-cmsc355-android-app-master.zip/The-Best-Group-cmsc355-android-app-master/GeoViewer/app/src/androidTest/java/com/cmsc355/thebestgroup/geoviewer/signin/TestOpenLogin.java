package com.cmsc355.thebestgroup.geoviewer.signin;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.amazonaws.mobile.user.signin.SignInManager;
import com.amazonaws.mobile.user.signin.SignInProvider;
import com.cmsc355.thebestgroup.geoviewer.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//test for Login user story, Open_Login scenario

@RunWith(AndroidJUnit4.class)
public class TestOpenLogin {

    @Rule
    public ActivityTestRule<SplashActivity> myActivityTestRule
            = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void testLoginScreen() {
        //Give time for screen to start up and see if logged in
        long start = System.currentTimeMillis();
        long end = System.currentTimeMillis();
        while (end - start < 5000) {
            end = System.currentTimeMillis();
        }

        SignInManager signInManager = SplashActivity.getSignInManager();
        SignInProvider provider = signInManager.getPreviouslySignedInProvider();
        //if logged in already, logout
        if (provider != null) {
            onView(withId(R.id.settingsButton)).perform(click());
            onView(withId(R.id.logout_button)).perform(click());
        }




        //Open app
        onView(withId(R.id.activity_splash));

        //Wait a certain amount on time for splash activity to timeout
        start = System.currentTimeMillis();
        end = System.currentTimeMillis();
        while ( end - start < 5000) {
            end = System.currentTimeMillis();
        }
        onView(withId(R.id.activity_sign_in)).check(matches(isDisplayed()));
    }
}
