package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.amazonaws.mobile.AWSMobileClient;
import com.cmsc355.thebestgroup.geoviewer.addphoto.AddPhotoToDatabaseActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;


//tests the Database Service Iteration 2 user story, AsyncMapper scenario

//tests the uploader by uploading a photo and waiting for response from the upload thread
//the debug log details waiting on the thread to finish
@RunWith(AndroidJUnit4.class)
public class TestMapper implements UploaderResponse {

    @Rule
    public ActivityTestRule<AddPhotoToDatabaseActivity> myActivityTestRule = new
            ActivityTestRule<>(AddPhotoToDatabaseActivity.class);

    @Test
    public void testUpload() {

        AWSMobileClient.initializeMobileClientIfNecessary(myActivityTestRule.getActivity());
        AsyncMapper uploadPhoto = new AsyncMapper();
        uploadPhoto.delegate = this;
        uploadPhoto.execute("/The-Best-Group-cmsc355-android-app/GeoViewer/app/src/main/res"
                + "/mipmap-hdpi/ic_launcher.png");
    }

    public void uploadFinished(Boolean result) {
        Boolean results = result;
    }
}
