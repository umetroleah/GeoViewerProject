package com.cmsc355.thebestgroup.geoviewer.unittests;

import com.amazonaws.models.nosql.PinsDO;
import com.cmsc355.thebestgroup.geoviewer.addphoto.AddPhotoToDatabaseActivity;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.AsyncMapper;
import com.cmsc355.thebestgroup.geoviewer.viewphoto.ViewPhotoActivity;
import com.cmsc355.thebestgroup.geoviewer.viewphoto.ViewPhotoFragment;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

/**
 * Created by mroseberry on 12/5/16.
 */

public class UnitTestsTdd1 {

    @Test
    public void test_AsyncMapper_generatePhotoId() {
        String string1 = AsyncMapper.generatePhotoId();
        String string2 = AsyncMapper.generatePhotoId();
        assertNotEquals(string1, string2);
        //Checks that the method generates unique id's
    }

    @Test
    public void test_AsyncMapper_creatPinForTable() {
        PinsDO myPin = AsyncMapper.createPinForTable("MY ID", 0.0, 1.0, "CAPTION", "USER");
        assertEquals(myPin.getPhotoId(), "MY ID");
        assertEquals((double)myPin.getLatitude(), 0.0, 0.01);
        assertEquals((double)myPin.getLongitude(), 1.0, 0.01);
        assertEquals(myPin.getCaption(), "CAPTION");
        assertEquals(myPin.getUserId(), "USER");

        myPin = AsyncMapper.createPinForTable(null, 0.0, 1.0, null, "");
        assertEquals(myPin, null);
    }

    @Test
    public void test_ViewPhotoFragment_generateTextViewText() {
        String result = ViewPhotoFragment.generateTextViewText(5);
        assertEquals(result, "Photo:5");

        result = ViewPhotoFragment.generateTextViewText(-5);
        assertEquals(result, null);
    }

    @Test
    public void test_AddPhotoToDatabaseActivity_createFileName() {
        String result = AddPhotoToDatabaseActivity.createFileName();

        assertThat(result,containsString("JPEG"));
    }

    @Test
    public void test_ViewPhotoActivity_createFileName_happy() {
        String result = ViewPhotoActivity.createFileName(null);

        assertEquals(result, null);
    }

    @Test
    public void test_ViewPhotoActivity_createFileName_sad1() {
        String result = ViewPhotoActivity.createFileName("");

        assertEquals(result, null);
    }

    @Test
    public void test_ViewPhotoActivity_createFileName_sad2() {
        String result = ViewPhotoActivity.createFileName("hello");

        assertEquals(result, "JPEG_hello_");
    }

}
