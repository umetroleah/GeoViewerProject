package com.cmsc355.thebestgroup.geoviewer.signin;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.amazonaws.mobile.user.signin.SignInManager;
import com.amazonaws.mobile.user.signin.SignInProvider;
import com.cmsc355.thebestgroup.geoviewer.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//test for Login user story, Previous_Login scenario

@RunWith(AndroidJUnit4.class)
public class TestPreviousLogin {

    @Rule
    public ActivityTestRule<SplashActivity> myActivityTestRule
            = new ActivityTestRule<>(SplashActivity.class);

    @Test
    public void testLogin() {
        Context context = myActivityTestRule.getActivity();
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        wifiManager.setWifiEnabled(true);


        //Give time for screen to start up and see if logged in
        long start = System.currentTimeMillis();
        long end = System.currentTimeMillis();
        while (end - start < 5000) {
            end = System.currentTimeMillis();
        }

        SignInManager signInManager = SplashActivity.getSignInManager();
        SignInProvider provider = signInManager.getPreviouslySignedInProvider();
        //if not logged in already, login
        if (provider == null) {
            onView(withId(R.id.g_login_button)).perform(click());
        }



        //Reopen app
        onView(withId(R.id.activity_splash));

        //Wait a certain amount on time for map to load up
        start = System.currentTimeMillis();
        end = System.currentTimeMillis();
        while (end - start < 5000) {
            end = System.currentTimeMillis();
        }

        onView(withId(R.id.map_activity_layout)).check(matches(isDisplayed()));
    }

}