package com.cmsc355.thebestgroup.geoviewer.viewmap;

import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;
import android.support.test.rule.ActivityTestRule;

import com.cmsc355.thebestgroup.geoviewer.R;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;

import org.junit.Rule;
import org.junit.Test;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.action.ViewActions.swipeLeft;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

//Test for Pan map manually user story. Move_Map scenario

public class TestGesture {

    @Rule
    public ActivityTestRule<MapsActivity> myActivityTestRule
            = new ActivityTestRule<>(MapsActivity.class);

    @Test
    public void testSwipe() {
        MockLocationProvider mock = new MockLocationProvider(LocationManager.GPS_PROVIDER,
                myActivityTestRule.getActivity() );

        //Set the location
        mock.pushLocation(10, 10);
        mock.shutdown();

        //Activate panning
        onView(withId(R.id.settingsButton)).perform(click());
        onView(withId(R.id.pan_switch)).perform(click());
        pressBack();

        final GoogleMap map = myActivityTestRule.getActivity().getCurrentMapFocus();

        //Pan the map
        swipeLeft();

        //Test if map is in a different location
        Handler uiHandler = new Handler(Looper.getMainLooper());
        Runnable runnable = new Runnable() {
            public void run() {
                CameraPosition cmr = map.getCameraPosition();
                LatLng loc = cmr.target;
                assert (loc.latitude != 10 || loc.longitude != 10);
            }
        };
        uiHandler.post(runnable);


    }

}
