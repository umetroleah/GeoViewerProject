package com.cmsc355.thebestgroup.geoviewer.viewmap;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.matcher.ViewMatchers.withText;

import android.location.LocationManager;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//tests View map centered on me user story, Map_No_Signal scenario

@RunWith(AndroidJUnit4.class)
public class TestLostSignal {

    @Rule
    public ActivityTestRule<MapsActivity> myActivityTestRule
            = new ActivityTestRule<>(MapsActivity.class);

    @Test
    public void lostSignalError() {
        MockLocationProvider mock = new MockLocationProvider(LocationManager.GPS_PROVIDER,
                myActivityTestRule.getActivity() );
        mock.shutdown();
        onView(withText("No GPS Signal Found"));
    }
}
