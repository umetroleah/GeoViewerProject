package com.cmsc355.thebestgroup.geoviewer.viewmap;


import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;

import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import junit.framework.TestCase;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//tests user story View map centered on me, Map_Stay_Centered scenario

@RunWith(AndroidJUnit4.class)
public class StaysCenter extends TestCase {

    @Rule
    public ActivityTestRule<MapsActivity> myActivityTestRule
            = new ActivityTestRule<>(MapsActivity.class);

    @Test
    public void mapStaysCenter() {
        MockLocationProvider mock = new MockLocationProvider(LocationManager.GPS_PROVIDER,
                myActivityTestRule.getActivity() );
        mock.pushLocation(10, 10);
        mock.shutdown();
        final GoogleMap map = myActivityTestRule.getActivity().getCurrentMapFocus();

        Handler uiHandler = new Handler(Looper.getMainLooper());
        Runnable runnable = new Runnable() {
            public void run() {
                CameraPosition cmr = map.getCameraPosition();
                LatLng loc = cmr.target;
                assert (loc.latitude == 10);
                assert (loc.longitude == 10);
            }
        };
        uiHandler.post(runnable);



    }
}
