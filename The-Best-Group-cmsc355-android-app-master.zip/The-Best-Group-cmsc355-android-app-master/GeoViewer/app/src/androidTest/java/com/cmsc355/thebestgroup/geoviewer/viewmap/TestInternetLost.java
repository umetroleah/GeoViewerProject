package com.cmsc355.thebestgroup.geoviewer.viewmap;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.support.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.RootMatchers.withDecorView;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;

//Test for Pan map manually user story. Lost_Internet scenario

public class TestInternetLost {

    @Rule
    public ActivityTestRule<MapsActivity> myActivityTestRule
            = new ActivityTestRule<>(MapsActivity.class);

    @Test
    public void testSignalError() {

        Context context = myActivityTestRule.getActivity();
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        wifiManager.setWifiEnabled(false);

        //Wait a certain amount on time for error message to appear
        final long start = System.currentTimeMillis();
        long end = System.currentTimeMillis();
        while (end - start < 700) {
            end = System.currentTimeMillis();
        }


        onView(withText("Error: No Internet"))
                .inRoot(withDecorView(not(is(myActivityTestRule.getActivity().getWindow().getDecorView()))))
                .check(matches(isDisplayed()));

    }
}
