package com.cmsc355.thebestgroup.geoviewer.settings;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.Espresso.pressBack;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.cmsc355.thebestgroup.geoviewer.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//test for View app about page user story, About_Go_Back scenario

@RunWith(AndroidJUnit4.class)
public class TestAboutGoBack {

    @Rule
    public ActivityTestRule<SettingsActivity> settingsActivityTestRule
            = new ActivityTestRule<>(SettingsActivity.class);

    @Test
    public void testAboutGoBack() {
        onView(withId(R.id.about_button)).perform(click());
        onView(withId(R.id.activity_about)).check(matches(isDisplayed()));

        pressBack();
        onView(withId(R.id.activity_settings)).check(matches(isDisplayed()));

    }

}