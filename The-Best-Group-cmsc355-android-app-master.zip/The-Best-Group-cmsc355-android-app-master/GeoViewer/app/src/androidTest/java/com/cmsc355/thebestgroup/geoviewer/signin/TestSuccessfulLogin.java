package com.cmsc355.thebestgroup.geoviewer.signin;

import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.cmsc355.thebestgroup.geoviewer.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

//test for Login user story, Successful_Login scenario

@RunWith(AndroidJUnit4.class)
public class TestSuccessfulLogin {

    @Rule
    public ActivityTestRule<SignInActivity> myActivityTestRule
            = new ActivityTestRule<>(SignInActivity.class);

    @Test
    public void testLogin() {
        Context context = myActivityTestRule.getActivity();
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        wifiManager.setWifiEnabled(true);

        onView(withId(R.id.g_login_button)).perform(click());

        //I gave the app the information for login manually, since I cannot access Google's code


        //Wait a certain amount on time for map to load
        final long start = System.currentTimeMillis();
        long end = System.currentTimeMillis();
        while (end - start < 2000) {
            end = System.currentTimeMillis();
        }

        onView(withId(R.id.map_activity_layout)).check(matches(isDisplayed()));
    }

}