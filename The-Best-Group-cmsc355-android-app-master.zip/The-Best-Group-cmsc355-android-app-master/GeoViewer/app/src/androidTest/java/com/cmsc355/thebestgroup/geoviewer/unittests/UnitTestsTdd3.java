package com.cmsc355.thebestgroup.geoviewer.unittests;

import android.content.Context;

import com.cmsc355.thebestgroup.geoviewer.viewmap.MapsActivity;

import org.junit.Test;
import org.mockito.Mock;

import static android.support.test.espresso.matcher.ViewMatchers.withId;

/**
 * Created by Michael on 12/4/2016.
 */

public class UnitTestsTdd3 {

    @Mock
    Context myMockContext;

    @Test
    public void test_MapsActivity_createAddPhotoIntent() {
        assert (MapsActivity.createAddPhotoIntent(myMockContext, 10, 10) != null);
    }
}
