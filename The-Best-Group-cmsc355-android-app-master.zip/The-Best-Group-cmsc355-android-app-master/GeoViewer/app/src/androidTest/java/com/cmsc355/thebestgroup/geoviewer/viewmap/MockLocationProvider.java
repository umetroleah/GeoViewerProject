package com.cmsc355.thebestgroup.geoviewer.viewmap;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;

/**
 * Created by Michael on 10/11/2016.
 */

public class MockLocationProvider {
    String providerName;
    Context context;

    public MockLocationProvider(String name, Context context) {
        this.providerName = name;
        this.context = context;

        LocationManager locationManager = (LocationManager) context.getSystemService(
                Context.LOCATION_SERVICE);
        locationManager.addTestProvider(providerName, false, false, false, false, false,
                true, true, 0, 5);
        locationManager.setTestProviderEnabled(providerName, true);
    }

    public void pushLocation(double lat, double lon) {
        final LocationManager locationManager = (LocationManager) context.getSystemService(
                Context.LOCATION_SERVICE);

        Location mockLocation = new Location(providerName);
        mockLocation.setLatitude(lat);
        mockLocation.setLongitude(lon);
        mockLocation.setAltitude(0);
        mockLocation.setTime(System.currentTimeMillis());
        mockLocation.setAccuracy(1);
        mockLocation.setElapsedRealtimeNanos(1000000);
        locationManager.setTestProviderLocation(providerName, mockLocation);
    }

    public void shutdown() {
        LocationManager lm = (LocationManager) context.getSystemService(
                Context.LOCATION_SERVICE);
        lm.removeTestProvider(providerName);
    }
}
