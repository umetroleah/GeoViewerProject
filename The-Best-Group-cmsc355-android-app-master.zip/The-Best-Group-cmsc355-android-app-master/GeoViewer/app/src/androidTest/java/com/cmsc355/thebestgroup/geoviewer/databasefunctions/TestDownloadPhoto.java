package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import com.amazonaws.mobile.AWSMobileClient;
import com.cmsc355.thebestgroup.geoviewer.addphoto.AddPhotoToDatabaseActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Created by freakofknuth on 10/12/16.+
 * Scenario: 3: Database_Download_Photo
 */

//test the Database Access for Iteration 1 user story, Database_Download_Photo scenario

//tests the photo download option by attempting to download and waiting for a response

@RunWith(AndroidJUnit4.class)
public class TestDownloadPhoto implements PhotoDownloaderResponse {

    @Rule
    public ActivityTestRule<AddPhotoToDatabaseActivity> myActivityTestRule = new
            ActivityTestRule<>(AddPhotoToDatabaseActivity.class);

    @Test
    public void testDownloadPhoto() {

        AWSMobileClient.initializeMobileClientIfNecessary(myActivityTestRule.getActivity());
        AsyncPhotoDownloader downloadedPhoto = new AsyncPhotoDownloader();
        downloadedPhoto.delegate = this;
        downloadedPhoto.execute("us-east-1:b68739c7-d0c3-4b0b-be5b-d3b70f9a2bfa.1203503234");
    }

    @Override
    public void photoDownloadFinished(String result) {
        String results = result;
    }
}

