package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

import com.amazonaws.models.nosql.PinsDO;

/**
 * Created by freakofknuth on 11/1/16.
 *
 */

//extracted interface in order to receive feedback from async task
public interface AsyncNearbyPinsResponse {
    void pinsDownloaded(PinsDO[] pins);
}
