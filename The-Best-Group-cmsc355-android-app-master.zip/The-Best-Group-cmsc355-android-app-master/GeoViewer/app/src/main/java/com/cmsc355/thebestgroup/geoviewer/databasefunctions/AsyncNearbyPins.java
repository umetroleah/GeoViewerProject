package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

import android.os.AsyncTask;
import android.util.Log;

import com.amazonaws.mobile.AWSMobileClient;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBScanExpression;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.PaginatedScanList;
import com.amazonaws.models.nosql.PinsDO;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import java.util.HashMap;
import java.util.Map;

//figure out which pins are nearby
public class AsyncNearbyPins extends AsyncTask<Double, Void, PinsDO[]> {

    //We need this in order to get feedback from the asyncTask
    public AsyncNearbyPinsResponse delegate = null;

    //Get the nearby pins on another thread
    protected PinsDO[] doInBackground(final Double... grid) {
        PinsDO[] pins = queryNearPins(grid[0],grid[1],grid[2],grid[3]);
        return pins;
    }

    //method for filtering and returning nearby pins
    public static PinsDO[] queryNearPins(
            Double latitude,
            Double latitude2,
            Double longitude,
            Double longitude2) {

        AmazonDynamoDBClient dbClient;
        try {
            dbClient = new AmazonDynamoDBClient(AWSMobileClient
                    .defaultMobileClient()
                    .getIdentityManager()
                    .getCredentialsProvider());
        } catch (NullPointerException exception) {
            Log.e("DB Function Exception", "One of the AWS objects seems not to "
                    + "have been intialized. Canceling DB call", exception);
            return null;
        }
        final DynamoDBMapper mapper = new DynamoDBMapper(dbClient);

        // Use an expression names Map to avoid the potential for attribute names
        // colliding with DynamoDB reserved words.
        final Map<String, String> filterExpressionAttributeNames = new HashMap<>();
        filterExpressionAttributeNames.put("#longitude", "longitude");
        filterExpressionAttributeNames.put("#latitude", "latitude");

        //creates a filter expression in order to avoid computing nearby pins locally
        final Map<String, AttributeValue> filterExpressionAttributeValues = new HashMap<>();
        filterExpressionAttributeValues.put(":minLong",
                new AttributeValue().withN(longitude + ""));
        filterExpressionAttributeValues.put(":maxLong",
                new AttributeValue().withN(longitude2 + ""));
        filterExpressionAttributeValues.put(":minLat",
                new AttributeValue().withN(latitude + ""));
        filterExpressionAttributeValues.put(":maxLat",
                new AttributeValue().withN(latitude2 + ""));

        //creates a scan expression for use by the AWS mapper
        final DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
                .withFilterExpression("(#longitude BETWEEN :minLong AND :maxLong) "
                        + "AND (#latitude BETWEEN :minLat AND :maxLat)")
                .withExpressionAttributeNames(filterExpressionAttributeNames)
                .withExpressionAttributeValues(filterExpressionAttributeValues);

        //list that allows examination of the database but cannot be modified
        //calls the scan using the filter
        PaginatedScanList<PinsDO> results = mapper.scan(PinsDO.class, scanExpression);

        //avoid null pointer
        if (results.size() == 0) {
            return null;
        }

        //return results in an array
        PinsDO[] temp = {new PinsDO()};
        return results.toArray(temp);
    }

    //allows access of member upon async task finished
    protected void onPostExecute(final PinsDO[] pins) {
        delegate.pinsDownloaded(pins);
    }
}
