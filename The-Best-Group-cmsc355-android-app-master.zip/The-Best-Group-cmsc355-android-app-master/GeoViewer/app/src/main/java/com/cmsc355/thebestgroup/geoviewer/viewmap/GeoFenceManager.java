/**
 * Originally Sourced from Google under the Apache License:
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * This file has been EDITED from Google's original version.
 *  https://github.com/googlesamples/android-play-location/tree/master/Geofencing
 */

package com.cmsc355.thebestgroup.geoviewer.viewmap;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingApi;
import com.google.android.gms.location.GeofencingEvent;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.Marker;

import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


/**
 * From Google:
 *      Uses an IntentService to monitor geofence transitions and creates notifications
 *      whenever a device enters or exits a geofence.
 *      This sample requires a device's Location settings to be turned on. It also requires
 *      the ACCESS_FINE_LOCATION permission, as specified in AndroidManifest.xml.
 * From us:
 *  More detailed comments will be added when user story is ready for completion.
 *  Purpose of class is to manage geofences, which fire event when user gets near a pin/photo.
 *  Need to figure out how to make events fire even in emulator - otherwise, all code is done.
 */
class GeoFenceManager {

    private static final int GEOFENCE_RADIUS = 150; //meters

    GoogleApiClient googleApiClient;
    private ArrayList<Geofence> geofenceList;
    private PendingIntent geofencePendingIntent;
    private Context context;
    private ArrayList<Geofence> geofencesInRange;

    GeoFenceManager(Context activContext) {
        geofenceList = new ArrayList<>();
        geofencePendingIntent = null;
        context = activContext;

        buildGoogleApiClient();
    }

    private synchronized void buildGoogleApiClient() {
        googleApiClient = new GoogleApiClient.Builder(context)
                .addApi(LocationServices.API)
                .build();
    }

    private GeofencingRequest getGeofencingRequest() {
        GeofencingRequest.Builder builder = new GeofencingRequest.Builder();

        // The INITIAL_TRIGGER_ENTER flag indicates that geofencing service should trigger a
        // GEOFENCE_TRANSITION_ENTER notification when the geofence is added and if the device
        // is already inside that geofence.
        builder.setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER);

        // Add the geofences to be monitored by geofencing service.
        builder.addGeofences(geofenceList);

        // Return a GeofencingRequest.
        return builder.build();
    }

    private void addGeoFences() {
        if (!googleApiClient.isConnected()) {
            Toast.makeText(context, "Not Connected", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            LocationServices.GeofencingApi.addGeofences(googleApiClient, getGeofencingRequest(),
                    // A pending intent that is reused when calling removeGeofences(). This
                    // pending intent is used to generate an intent when a matched geofence
                    // transition is observed.
                    getGeofencePendingIntent()
            );

        } catch (SecurityException securityException) {
            // Catch exception generated if the app does not use ACCESS_FINE_LOCATION permission.
            Log.e("Exception", "Security Exception", securityException);
        }
    }

    private void removeGeoFences() {
        if (!googleApiClient.isConnected()) {
            Toast.makeText(context, "Not Connected", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            LocationServices.GeofencingApi.removeGeofences(googleApiClient,
                    // A pending intent that is reused when calling removeGeofences(). This
                    // pending intent is used to generate an intent when a matched geofence
                    // transition is observed.
                    getGeofencePendingIntent()
            );

        } catch (SecurityException securityException) {
            // Catch exception generated if the app does not use ACCESS_FINE_LOCATION permission.
            Log.e("Exception", "Security Exception", securityException);
        }
    }

    /**
     * Gets a PendingIntent to send with the request to add or remove Geofences. Location Services
     * issues the Intent inside this PendingIntent whenever a geofence transition occurs for the
     * current list of geofences.
     *
     * @return A PendingIntent for the IntentService that handles geofence transitions.
     */
    private PendingIntent getGeofencePendingIntent() {
        if (geofencePendingIntent != null) {
            return geofencePendingIntent;
        }
        Intent intent = new Intent(context, GeofenceTransitionsIntentService.class);
        // We use FLAG_UPDATE_CURRENT so that we get the same pending intent back when calling
        // addGeofences() and removeGeofences().
        return PendingIntent.getService(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    void populateGeofenceList(ArrayList<Marker> photoMarkers) {
        removeGeoFences();

        for (Marker photo : photoMarkers) {
            geofenceList.add(new Geofence.Builder()
                    .setRequestId((String) photo.getTag())
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .setCircularRegion(photo.getPosition().latitude,
                            photo.getPosition().longitude, GEOFENCE_RADIUS)
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER
                            | Geofence.GEOFENCE_TRANSITION_EXIT)
                    .build());
        }
        addGeoFences();
    }

    protected class GeofenceTransitionsIntentService extends IntentService {
        /**
         * Listener for geofence transition changes.
         *
         * <p>Receives geofence transition events from Location Services
         *      in the form of an Intent containing
         * the transition type and geofence id(s) that triggered the transition.</p>
         */

        /**
         * This constructor is required
         */
        public GeofenceTransitionsIntentService() {
            // Use the TAG to name the worker thread.
            super("GeoFences Service");
            geofencesInRange = new ArrayList<>();
        }

        /**
         * Handles incoming intents.
         * @param intent sent by Location Services. This Intent is provided to Location
         *               Services (inside a PendingIntent) when addGeofences() is called.
         */
        @Override
        protected void onHandleIntent(Intent intent) {
            GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);

            int geofenceTransition = geofencingEvent.getGeofenceTransition();

            if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER) {
                if (geofencesInRange.isEmpty()) {
                    ((MapsActivity) context).photosInRange(true);   //no longer will be empty
                }

                // Get the geofences that were triggered.
                // A single event can trigger multiple geofences.
                List<Geofence> triggeringGeofences = geofencingEvent.getTriggeringGeofences();
                geofencesInRange.addAll(triggeringGeofences);
            } else if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT) {
                List<Geofence> triggeringGeofences = geofencingEvent.getTriggeringGeofences();
                geofencesInRange.removeAll(triggeringGeofences);

                if (geofencesInRange.isEmpty()) {
                    ((MapsActivity) context).photosInRange(false);
                }
            }
        }
    }

    //getter / convenience method. Used by external classes.
    ArrayList<Geofence> getGeofencesInRange() {
        return new ArrayList<>(geofencesInRange);
    }
}
