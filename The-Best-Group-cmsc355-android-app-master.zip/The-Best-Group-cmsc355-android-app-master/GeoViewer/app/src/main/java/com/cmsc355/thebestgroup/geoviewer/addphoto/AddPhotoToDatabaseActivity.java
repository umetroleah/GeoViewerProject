package com.cmsc355.thebestgroup.geoviewer.addphoto;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.cmsc355.thebestgroup.geoviewer.R;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.AsyncMapper;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.UploaderResponse;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
*   Activity for taking a photo and uploading it to the database. Includes methods for creating
*   an image file, taking the photo using the camera, updating the activity on the camera results
*   and submitting the photo to the database, and receiving a boolean from the database in response.
*
 */

public class AddPhotoToDatabaseActivity extends AppCompatActivity implements UploaderResponse {

    private static final int CAMERA_REQUEST = 1;
    private ImageView imageView;
    private Button submitButton;
    private EditText caption;
    String photoFilePath;
    String latitude;
    String longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_photo_to_database);
        latitude = getIntent().getStringExtra("lat");
        longitude = getIntent().getStringExtra("lng");

        this.imageView = (ImageView) this.findViewById(R.id.photoImageView);
        this.submitButton = (Button) this.findViewById(R.id.submitButton);
        this.caption = (EditText) this.findViewById(R.id.captionText);
        submitButton.setEnabled(false);
        caption.setEnabled(false);


        ImageButton cameraButton = (ImageButton) this.findViewById(R.id.cameraButton);
        cameraButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                takePhoto();
            }
        });
    }

    //after a photo is taken, display it and enable the submit button
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {

            this.submitButton.setEnabled(true);
            this.caption.setEnabled(true);
            this.caption.setHint(R.string.caption_tip);
            imageView.setImageURI(Uri.parse(photoFilePath));
        }
    }

    public static String createFileName() {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = "JPEG_" + timeStamp + "_";

        return fileName;
    }

    //creates a file for photo
    private File createPhotoFile() throws IOException {
        // Create an image file name
        String photoFileName = createFileName();
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File photoFile = File.createTempFile(photoFileName, ".jpg", storageDir);

        // Save the file path
        photoFilePath = photoFile.getAbsolutePath();
        return photoFile;
    }

    //uses the camera to take a photo and store it on the phone
    public void takePhoto() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createPhotoFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                Context context = getApplicationContext();
                CharSequence text = "Error. Try again.";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photouri = FileProvider.getUriForFile(this,
                        "com.cmsc355.thebestgroup.geoviewer.fileprovider",
                        photoFile);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photouri);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            }
        }
    }

    //if the phone is connected, uploads the photo. Else, displays error message.
    public void submitPhoto(View view) {

        EditText captionText = (EditText) findViewById(R.id.captionText);
        String caption = captionText.getText().toString();



        //Check if the photo is connected to the internet
        ConnectivityManager cm
                = (ConnectivityManager) getApplicationContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        if (isConnected) {

            AsyncMapper asyncMapper = new AsyncMapper();
            asyncMapper.delegate = this;
            asyncMapper.execute(latitude, longitude, caption, photoFilePath);
        } else {
            Context context = getApplicationContext();
            CharSequence text = "No network connection. Try again.";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
    }

    //Upon finishing the asynchronous upload, prints a toast message based on the returned result
    public void uploadFinished(Boolean result) {

        Boolean photoSubmitted = result;

        if (photoSubmitted) {
            Context context = getApplicationContext();
            CharSequence text = "Photo submitted";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

            finish();
        } else {
            Context context = getApplicationContext();
            CharSequence text = "Error. Try again";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

    }
}