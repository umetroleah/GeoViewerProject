package com.cmsc355.thebestgroup.geoviewer.databasefunctions;


import android.os.AsyncTask;

import java.io.IOException;

/*
 * Created by mroseberry on 10/11/16.
 *
 * Async task for downloading individual photo files.
 */
public class AsyncPhotoDownloader extends AsyncTask<String, Void, String> {

    //member for feedback
    public PhotoDownloaderResponse delegate = null;

    //params: String filePath, String photoKey
    @Override
    protected String doInBackground(final String... params) {
        String filePath = params[0];
        String photoTag = params[1];

        //create FileManager & download photo corresponding to key
        FileManager downObj = null;
        try {
            downObj = new FileManager(filePath);
        } catch (IOException exception) {
            exception.printStackTrace();
            return null;    //failed
        }
        try {
            downObj.download(photoTag, filePath);
        } catch (IOException exception) {
            exception.printStackTrace();
            return null;    //failed
        }

        return filePath;    //succeeded
    }

    //occurs on async task completed
    @Override
    protected void onPostExecute(String response) {
        delegate.photoDownloadFinished(response);
    }
}
