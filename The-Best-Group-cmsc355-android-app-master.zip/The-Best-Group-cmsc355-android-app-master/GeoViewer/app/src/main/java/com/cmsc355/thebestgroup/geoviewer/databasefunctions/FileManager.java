package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

import android.os.Bundle;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.mobile.AWSMobileClient;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by freakofknuth on 10/4/16.
 *
 */

public class FileManager {

    //bucket and file name members
    private static String bucketName     = "geoviewer-photos";
    private static String fileString;

    //FileManager constructor
    public FileManager(String fileName) throws IOException {
        fileString = fileName;
    }

    //uploads a photo to the photo bucket
    public void upload() throws IOException {

        AmazonS3 s3client = new AmazonS3Client(AWSMobileClient.defaultMobileClient()
                .getIdentityManager()
                .getCredentialsProvider());

        try {
            System.out.println("Uploading a new object to S3 from a file\n");
            File file = new File(fileString);
            s3client.putObject(new PutObjectRequest(bucketName, fileString, file));

        } catch (AmazonServiceException ase) {
            System.out.println("Caught an AmazonServiceException, which "
                    + "means your request made it "
                    + "to Amazon S3, but was rejected with an error response"
                    + " for some reason.");
            System.out.println("Error Message:    " + ase.getMessage());
            System.out.println("HTTP Status Code: " + ase.getStatusCode());
            System.out.println("AWS Error Code:   " + ase.getErrorCode());
            System.out.println("Error Type:       " + ase.getErrorType());
            System.out.println("Request ID:       " + ase.getRequestId());
        } catch (AmazonClientException ace) {
            System.out.println("Caught an AmazonClientException, which "
                    + "means the client encountered "
                    + "an internal error while trying to "
                    + "communicate with S3, "
                    + "such as not being able to access the network.");
            System.out.println("Error Message: " + ace.getMessage());
        }
    }

    //download photo from the bucket
    public void download(String photoKey, String filePath) throws IOException {

        //initialize the AWS client
        AmazonS3 s3client = new AmazonS3Client(AWSMobileClient.defaultMobileClient()
                .getIdentityManager()
                .getCredentialsProvider());

        //getObject with photoKey
        try {
            System.out.println("Downloading an object from S3 to a file\n");
            S3Object object = s3client.getObject(new GetObjectRequest(bucketName, photoKey));

            InputStream objectData = object.getObjectContent();
            OutputStream output = new FileOutputStream(filePath);
            int read = -1;
            while ((read = objectData.read()) != -1) {
                output.write(read);
            }
            output.close();

        } catch (AmazonServiceException ase) {
            System.out.println("Caught an AmazonServiceException, which "
                    + "means your request made it "
                    + "to Amazon S3, but was rejected with an error response"
                    + " for some reason.");
            System.out.println("Error Message:    " + ase.getMessage());
            System.out.println("HTTP Status Code: " + ase.getStatusCode());
            System.out.println("AWS Error Code:   " + ase.getErrorCode());
            System.out.println("Error Type:       " + ase.getErrorType());
            System.out.println("Request ID:       " + ase.getRequestId());
        } catch (AmazonClientException ace) {
            System.out.println("Caught an AmazonClientException, which "
                    + "means the client encountered "
                    + "an internal error while trying to "
                    + "communicate with S3, "
                    + "such as not being able to access the network.");
            System.out.println("Error Message: " + ace.getMessage());
        }
    }

    //download all photos
    public Bundle getObjectList() throws IOException {

        //initialize AWS
        AmazonS3 s3client = new AmazonS3Client(AWSMobileClient.defaultMobileClient()
                .getIdentityManager()
                .getCredentialsProvider());

        //get a list of all the photo objects
        System.out.println("Listing objects");
        ObjectListing objects = s3client.listObjects(new ListObjectsRequest()
                .withBucketName(bucketName));

        //store information about photos
        ArrayList<String> keys = new ArrayList<>();
        ArrayList<Double> lats = new ArrayList<>();
        ArrayList<Double> lons = new ArrayList<>();
        for (S3ObjectSummary objectSummary : objects.getObjectSummaries()) {
            String key = objectSummary.getKey();

            if (key.contains("storage")) {
                Scanner parser = new Scanner(key).useDelimiter("_");
                String throwaway = parser.next();
                double lat = parser.nextDouble();
                double lon = parser.nextDouble();

                keys.add(key);
                lats.add(new Double(lat));
                lons.add(new Double(lon));
            }
        }

        String[] keysArray = keys.toArray(new String[0]);
        double[] latsArray = new double[lats.size()];
        for (int i = 0; i < latsArray.length; i++) {
            latsArray[i] = lats.get(i);
        }
        double[] lonsArray = new double[lons.size()];
        for (int i = 0; i < lonsArray.length; i++) {
            lonsArray[i] = lons.get(i);
        }

        //return a bundle of photo information arrays
        Bundle bundle = new Bundle();
        bundle.putStringArray("keys", keysArray);
        bundle.putDoubleArray("lats", latsArray);
        bundle.putDoubleArray("lons", lonsArray);
        return bundle;
    }
}


