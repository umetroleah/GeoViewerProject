/**
 * Makes use of sample code from Google API and Android Tutorials.
 */

package com.cmsc355.thebestgroup.geoviewer.viewmap;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.VisibleRegion;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.amazonaws.models.nosql.PinsDO;
import com.cmsc355.thebestgroup.geoviewer.R;
import com.cmsc355.thebestgroup.geoviewer.addphoto.AddPhotoToDatabaseActivity;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.AsyncNearbyPins;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.AsyncNearbyPinsResponse;
import com.cmsc355.thebestgroup.geoviewer.settings.SettingsActivity;
import com.cmsc355.thebestgroup.geoviewer.viewphoto.ViewPhotoActivity;

import java.util.ArrayList;

/**
 * The main activity of our app. Displays a map centered on the device's GPS location and location
 * of photos in the database.
 * Includes buttons to access other Activities, including Settings, AddPhoto, and others.
 * VisitPhoto is only accessible when enabled based on a Geofence Entrance event.
 * Makes heavy use of multiple listeners and threading.
 */
public class MapsActivity extends FragmentActivity implements
        OnMapReadyCallback, AsyncNearbyPinsResponse {

    private GoogleMap googleMap;
    private LatLng userLocation;
    private Marker userMarker;
    private ArrayList<Marker> photoMarkers;
    private GeoFenceManager geoFenceManager;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor preferenceEditor;
    private static final int PREFERENCE_MODE_PRIVATE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        if (!isNetworkStatusAvialable(getApplicationContext())) {
            Toast.makeText(getApplicationContext(), "Error: No Internet", Toast.LENGTH_SHORT).show();
        }

        Button viewPhotoBtn = (Button) this.findViewById(R.id.viewPhotoButton);
        viewPhotoBtn.setEnabled(true); //Not enabled until Geofences tell us we're near a pin
        //TODO: setEnabled(false). true for testing only

        //Initializes the location manager, and checks for GPS location permissions
        LocationManager manager = null;
        while (manager == null) {
            manager = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                        this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                                    Manifest.permission.INTERNET}, 1);
                    return;
                }
            }
            if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
                Context context = getApplicationContext();
                CharSequence text = "No GPS Signal Found";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        }

        //sets the starting user location to the last known location
        Location startLocation = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (startLocation != null) {
            double startLat = startLocation.getLatitude();
            double startLng = startLocation.getLongitude();
            userLocation = new LatLng(startLat, startLng);
        } else {
            userLocation = new LatLng(0,0); //no known location
        }

        //Initializes map and location update manager
        manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, locListener);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        //Initializes GeofenceManager, so that it can connect to Google API.
        //We wait to load pins & geofences until Map is ready
        geoFenceManager = new GeoFenceManager(this);

        //Next events will be: onStart() and onMapReady()
    }

    public static boolean isNetworkStatusAvialable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo netInfos = connectivityManager.getActiveNetworkInfo();
            if (netInfos != null) {
                if (netInfos.isConnected()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * This listener responds to a change in physical user location.
     * In onCreate(), we can set how much of a change is needed to fire.
     * On a change, we must update the map's focus, load releveant pins,
     * and manage geofences.
     */
    LocationListener locListener = new LocationListener() {

        @Override
        public void onLocationChanged(Location location) {
            if (googleMap == null) {
                return;
            }   //in case a location event fires before the map has initialized.

            userLocation = new LatLng(location.getLatitude(), location.getLongitude());


            sharedPreferences = getSharedPreferences("SettingsActivity", PREFERENCE_MODE_PRIVATE);
            boolean center = sharedPreferences.getBoolean("Center", false);


            //change current focus of map
            if (!center) {
                googleMap.moveCamera(CameraUpdateFactory.newLatLng(userLocation));
                googleMap.getUiSettings().setScrollGesturesEnabled(false);
            } else {
                googleMap.getUiSettings().setScrollGesturesEnabled(true);
            }

            userMarker.remove();
            userMarker = googleMap.addMarker(
                    new MarkerOptions().position(userLocation).title("You"));
            userMarker.setTag("User"); //when removed, Map will have autoset tag to null

            populatePhotoMarkers(); //Need to load pins within current focus
        }

        @Override
        public void onStatusChanged(String status, int integer, Bundle bundle) {}

        @Override
        public void onProviderEnabled(String string) {}

        //What happens if gps gets turned off: https://www.youtube.com/watch?v=QNb_3QKSmMk
        @Override
        public void onProviderDisabled(String string) {}
    };

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera.
     * If Google Play services is not installed on the device,
     * the userMarker will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the userMarker has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;

        sharedPreferences = getSharedPreferences("SettingsActivity", PREFERENCE_MODE_PRIVATE);
        boolean center = sharedPreferences.getBoolean("Center", false);

        //The user cannot scroll, but they can rotate the map.
        this.googleMap.getUiSettings().setScrollGesturesEnabled(center);
        this.googleMap.getUiSettings().setRotateGesturesEnabled(true);

        this.googleMap.setMyLocationEnabled(true);

        //Initialized the camera's zoom
        this.googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLocation,17));

        //Initializes the user marker
        userMarker = this.googleMap.addMarker(
                new MarkerOptions().position(userLocation).title("You")
                        .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_me)));
        userMarker.setTag("User");

        populatePhotoMarkers(); //load markers into our initial view
    }


    /**
     * Used to initialize googleAPI connection for use by geofence
     */
    @Override
    protected void onStart() {
        super.onStart();
        geoFenceManager.googleApiClient.connect();
    }

    @Override
    protected void onStop() {
        super.onStop();
        geoFenceManager.googleApiClient.disconnect();
    }

    /**
     * Method to begin delete old markers and load new ones.
     * Begins download of markers for current view from database.
     */
    public void populatePhotoMarkers() {
        if (photoMarkers == null) {
            photoMarkers = new ArrayList<>();
        }   //initializes ArrayList

        //Gets current visible coordinates
        VisibleRegion vr = googleMap.getProjection().getVisibleRegion();
        double minLong = vr.latLngBounds.southwest.longitude;
        double maxLat = vr.latLngBounds.northeast.latitude;
        double maxLong = vr.latLngBounds.northeast.longitude;
        double minLat = vr.latLngBounds.southwest.latitude;

        //Initializes downloaded of nearby pins.
        AsyncNearbyPins downloadMarkers = new AsyncNearbyPins();
        downloadMarkers.delegate = this;
        downloadMarkers.execute(minLat, maxLat, minLong, maxLong);

        //Next event to occur will be pinsDownloaded()
    }

    /**
     * Required for AsyncNearbyPins interface.
     * Responds to completion of database download.
     * Deletes old pins from map. Loads in new ones.
     * Then initializes geofence loading.
     */
    public void pinsDownloaded(PinsDO[] pins) {
        photoMarkers.clear();
        googleMap.clear();

        //because we just cleared all markers
        userMarker = googleMap.addMarker(
                new MarkerOptions().position(userLocation).title("You")
                        .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_me)));

        if (pins != null) {
            for (int i = 0; i < pins.length; i++) {
                Marker newMarker = googleMap.addMarker(new MarkerOptions()
                        .position(new LatLng(pins[i].getLatitude(), pins[i].getLongitude()))
                        .icon(BitmapDescriptorFactory.fromResource(R.mipmap.ic_photo_marker)));

                newMarker.setTag(pins[i].getUserId() + "." + pins[i].getPhotoId()); //userid.photoid
                photoMarkers.add(newMarker);
            }
            this.findViewById(R.id.viewPhotoButton).setEnabled(true);
        } else {
            this.findViewById(R.id.viewPhotoButton).setEnabled(false);
        }

        //geoFenceManager.populateGeofenceList(photoMarkers);
        // hands off new list to geofence manager
    }

    /**
     * Listener for button click to move to addPhotoActivity
     * Does require that the map be available to provide location.
     */
    public void addPhotoListener(View view) {
        Intent photoIntent = createAddPhotoIntent(view.getContext(), userLocation.latitude, userLocation.longitude);
        
        /*Intent photoIntent = new Intent(view.getContext(), AddPhotoToDatabaseActivity.class);

        String latitude = String.format("%.5f", userLocation.latitude);
        String longitude = String.format("%.5f", userLocation.longitude);
        photoIntent.putExtra("lat",latitude);
        photoIntent.putExtra("lng",longitude);*/

        startActivity(photoIntent);
    }

    public static Intent createAddPhotoIntent(Context context, double latitude, double longitude) {
        Intent photoIntent = new Intent(context, AddPhotoToDatabaseActivity.class);

        String lat = String.format("%.5f", latitude);
        String lon = String.format("%.5f", longitude);
        photoIntent.putExtra("lat",lat);
        photoIntent.putExtra("lng",lon);

        return photoIntent;
    }

    /**
     * Listener for button to move to settingActivity
     * No pre- or post- conditions required
     */
    public void settingsListener(View view) {
        Intent settingsIntent = new Intent(view.getContext(), SettingsActivity.class);
        startActivity(settingsIntent);
    }

    /**
     * Listener for Geofence events fired by geofencemanager.
     * Events are fired / photosInRange is called when the VisitPhoto button should be enabled
     * or disabled.
     * i.e. it's called when the list becomes empty of non-empty.
     */
    protected void photosInRange(boolean sentinel) {
        /**
         * 1 = photos have come in range
         * 0 = no more photos in range
         */
        if (sentinel) {
            Button viewPhotoBtn = (Button) this.findViewById(R.id.viewPhotoButton);
            viewPhotoBtn.setEnabled(true);
        } else {
            Button viewPhotoBtn = (Button) this.findViewById(R.id.viewPhotoButton);
            viewPhotoBtn.setEnabled(false);
        }
    }

    /**
     * Listener for button to move to visitPhotoActivity
     * Only possible to click when photos are in range.
     * Pulls all nearby pin/photoIDs.
     * Creates intent to VisitPhoto with Tags,Lats,and Longs of pins.
     */
    public void viewPhotoListener(View view) {
        /*ArrayList<Geofence> geoFences = geoFenceManager.getGeofencesInRange();

        String[] tags = new String[geoFences.size()];
        for (int i = 0; i < tags.length; i++) {
            tags[i] = geoFences.get(i).getRequestId();
        }
        Marker[] nearbyMarkers = new Marker[geoFences.size()];
        for (int i = 0; i < tags.length; i++) {
            //Todo: improve implementation. Seems inefficient to iterate so much
            for (Marker marker : photoMarkers) {
                if (marker.getTag().equals(tags[i])) {
                    nearbyMarkers[i] = marker;
                    break;
                }
            }
        }
        double[] lats = new double[tags.length];
        double[] longs = new double[tags.length];
        for (int i = 0; i < lats.length; i++) {
            lats[i] = nearbyMarkers[i].getPosition().latitude;
            longs[i] = nearbyMarkers[i].getPosition().longitude;
        }*/
        String[] tags = new String[photoMarkers.size()];
        for (int i = 0; i < tags.length; i++) {
            tags[i] = (String) photoMarkers.get(i).getTag();
        }
        double[] lats = new double[tags.length];
        double[] longs = new double[tags.length];
        for (int i = 0; i < lats.length; i++) {
            lats[i] = photoMarkers.get(i).getPosition().latitude;
            longs[i] = photoMarkers.get(i).getPosition().longitude;
        }

        Intent intent = new Intent(this, ViewPhotoActivity.class);
        intent.putExtra("tags", tags);
        intent.putExtra("lats", lats);
        intent.putExtra("longs", longs);
        startActivity(intent);
    }

    //Used in some tests, and other external classes. For convenience.
    public GoogleMap getCurrentMapFocus() {
        return googleMap;
    }
}
