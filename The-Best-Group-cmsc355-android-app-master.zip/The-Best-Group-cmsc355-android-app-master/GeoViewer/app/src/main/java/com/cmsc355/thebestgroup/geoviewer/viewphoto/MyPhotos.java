package com.cmsc355.thebestgroup.geoviewer.viewphoto;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.widget.Toast;

import com.amazonaws.mobile.AWSMobileClient;
import com.amazonaws.mobile.user.IdentityManager;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBQueryExpression;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.PaginatedQueryList;
import com.amazonaws.models.nosql.PinsDO;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.cmsc355.thebestgroup.geoviewer.R;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.AsyncPhotoDownloader;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.PhotoDownloaderResponse;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by freakofknuth on 11/26/16.
 * Allows a particular user to view all photos which they have posted
 * utilizing Justin's previously created pager.
 * This page is reachable through settings.
 */

public class MyPhotos extends FragmentActivity  {

    ViewPhotoPagerAdapter pagerAdapter;
    ViewPager photoViewPager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_photos);

        //We need intent so that we may reference table elements by userId
        Intent intent = getIntent();

        //pageAdapter will help dynamically manage fragments within pager.
        //This constructor will handle creation of fragments, so we pass photo info/intent
        pagerAdapter = new ViewPhotoPagerAdapter(getSupportFragmentManager(), intent);
        photoViewPager = (ViewPager) findViewById(R.id.mypager);
        photoViewPager.setAdapter(pagerAdapter);
    }


    //The PagerAdapter manages creation (sometimes dynamically) of fragments for our pager.
    public class ViewPhotoPagerAdapter extends FragmentStatePagerAdapter
            implements PhotoDownloaderResponse {

        private ArrayList<Fragment> photoFragmentList;
        private ArrayList<Bundle> photosPendingDownload;

        @Override
        public Fragment getItem(int index) {
            return photoFragmentList.get(index);
        }

        @Override
        public int getCount() {
            return photoFragmentList.size();
        }

        //View all photos posted by the current user
        public ViewPhotoPagerAdapter(FragmentManager fm, Intent intent) {
            super(fm);

            photoFragmentList = new ArrayList<Fragment>();
            photosPendingDownload = new ArrayList<Bundle>();

            //Pull current userId from intent and create a list of pins related to this userId
            String userId = intent.getStringExtra("userId");
            PinsDO[] pins = queryUserPins();

            //go through the list of pins and download the photos in a temp file for viewing
            for (PinsDO pin : pins) {

                String photoFile = null;

                try {
                    photoFile = createPhotoFile();
                } catch (IOException ex) {
                    // Error occurred while creating the File
                    Context context = getApplicationContext();
                    CharSequence text = "Error. Try again.";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
                // Continue only if the File was successfully created
                if (photoFile != null) {

                    //Download photos by photoId member
                    AsyncPhotoDownloader photoDownloader = new AsyncPhotoDownloader();
                    photoDownloader.delegate = this;
                    photoDownloader.execute(photoFile, pin.getPhotoId());
                    Bundle bundle = new Bundle();
                    bundle.putString("filePath",photoFile);
                    photosPendingDownload.add(bundle);
                }
            }
        }

        //creates a file for photo
        private String createPhotoFile() throws IOException {

            // Create an image file name
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String photoFileName = "JPEG_" + timeStamp + "_";
            File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File photoFile = File.createTempFile(photoFileName, ".jpg", storageDir);

            // Save the file path
            return photoFile.getAbsolutePath();
        }

        public void photoDownloadFinished(String filePath) {
            if (filePath == null) {   //failed
                Context context = getApplicationContext();
                CharSequence text = "Error. Try again";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }

            Bundle bundle = null;
            for (Bundle current : photosPendingDownload) {
                if (current.getString("filePath").equals(filePath)) {
                    bundle = current;
                    break;
                }
            }
            photosPendingDownload.remove(bundle);

            ViewPhotoFragment newFrag = new ViewPhotoFragment();
            newFrag.setArguments(bundle);
            photoFragmentList.add(newFrag);

            notifyDataSetChanged(); //required by FragmentStatePagerAdapter
        }
    }

    //figure out which pins belong to a particular user
    public static PinsDO[] queryUserPins() {

        AmazonDynamoDBClient dbClient;
        try {
            dbClient = new AmazonDynamoDBClient(AWSMobileClient
                    .defaultMobileClient()
                    .getIdentityManager()
                    .getCredentialsProvider());
        } catch (NullPointerException exception) {
            Log.e("DB Function Exception", "One of the AWS objects seems not to "
                    + "have been intialized. Canceling DB call", exception);
            return null;
        }
        final DynamoDBMapper mapper = new DynamoDBMapper(dbClient);

        final IdentityManager identityManager = AWSMobileClient.defaultMobileClient()
                .getIdentityManager();
        String userId = identityManager.getCachedUserID();

        PinsDO pins = new PinsDO();
        pins.setUserId(userId);

        //creates a query in order to return pins by userId with AWS
        DynamoDBQueryExpression queryExpression = new DynamoDBQueryExpression()
                .withHashKeyValues(pins);

        //list that allows examination of the database but cannot be modified
        //calls the scan using the filter
        PaginatedQueryList<PinsDO> results = mapper.query(PinsDO.class, queryExpression);

        //avoid null pointer
        if (results.size() == 0) {
            return null;
        }

        //return results in an array
        PinsDO[] temp = {new PinsDO()};
        return results.toArray(temp);
    }
}
