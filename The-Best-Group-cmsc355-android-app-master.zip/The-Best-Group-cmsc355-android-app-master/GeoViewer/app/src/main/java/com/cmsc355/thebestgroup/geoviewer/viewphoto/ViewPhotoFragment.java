package com.cmsc355.thebestgroup.geoviewer.viewphoto;

import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.cmsc355.thebestgroup.geoviewer.R;

/**
 * Fragments within a pager, within ViewPhotoActivity.
 * Responsible for displaying a photo, corresdponing info, and a back button.
 */
public class ViewPhotoFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_view_photo, container, false);

        Bundle args = getArguments();
        String photoFilePath = args.getString("filePath");

        ImageView imgView = (ImageView) rootView.findViewById(R.id.photo);
        imgView.setImageURI(Uri.parse(photoFilePath));

        TextView textView = (TextView) rootView.findViewById(R.id.photo_label);
        textView.setText(generateTextViewText(args.getInt("photoNumber")));

        return rootView; //needed by our pager, so it can manage fragment.
    }

    public static String generateTextViewText(int photoNumber) {
        if (photoNumber < 0) {
            return null;
        } else {
            return "Photo:" + photoNumber;
        }
    }
}
