package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

/*
 * Created by mroseberry on 10/10/16.
 *
 * Interface to assist getting data from AsyncUploader
 */

public interface UploaderResponse {
    void uploadFinished(Boolean result);
}
