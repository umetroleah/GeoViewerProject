package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

import android.os.AsyncTask;

import com.amazonaws.mobile.AWSMobileClient;
import com.amazonaws.mobile.user.IdentityManager;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.models.nosql.PinsDO;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.PutObjectRequest;

import java.io.File;
import java.io.IOException;
import java.util.Random;

/**
 * Created by freakofknuth on 10/30/16..
 *
 */

//Creates a table object, modifies it, and updates the database
public class AsyncMapper extends AsyncTask<String, Void, Boolean> {


    public UploaderResponse delegate = null;

    /**
     * Take in some paramters
     * Assign random photoId to photo
     * Add info to table
     * Add photo to bucket
     */

    //Parameters: latitude, longitude, caption, file location
    @Override
    protected Boolean doInBackground(final String... params) {
        final Double latitude = Double.parseDouble(params[0]);
        final Double longitude = Double.parseDouble(params[1]);
        final String caption = params[2];
        final String filepath = params[3];

        //figure out who the user is so that we can attach their uploads to them
        String userId = AWSMobileClient.defaultMobileClient()
                .getIdentityManager().getCachedUserID();
        if (userId == null) {
            final String[] updatedId = new String[1];
            AWSMobileClient.defaultMobileClient().getIdentityManager()
                    .getUserID(new IdentityManager.IdentityHandler() {
                        @Override
                        public void handleIdentityID(String identityId) {
                            updatedId[0] = identityId;
                        }

                        @Override
                        public void handleError(Exception exception) {
                            updatedId[0] = null;
                        }
                    });
            userId = updatedId[0];
        }
        if (userId == null) {
            return false;
        }

        //call random generator method
        String photoId = generatePhotoId();

        //add to table
        try {
            PinsDO newPin = createPinForTable(photoId, latitude, longitude, caption,userId);
            addToTable(newPin);
        } catch (IOException exception) {
            exception.printStackTrace();
        }

        //get credentials then addToBucket
        String bucketName     = "geoviewer-photos";
        AmazonS3 s3client = new AmazonS3Client(AWSMobileClient.defaultMobileClient()
                .getIdentityManager()
                .getCredentialsProvider());

        //tell amazon where to store in the bucket
        File file = new File(filepath);
        s3client.putObject(new PutObjectRequest(bucketName, userId + "." + photoId, file));

        return true;
    }

    //allows notification upon async task finish
    @Override
    protected void onPostExecute(final Boolean result) {
        delegate.uploadFinished(result);

    }

    //generate random photoId in order to reduce change of duplication
    public static String generatePhotoId() {
        Random generator = new Random();
        int newId = generator.nextInt();
        return newId + "";
    }

    //return codes: 1=good. 0=duplicate photoId, -1=other error
    public static void addToTable(PinsDO newPin) throws IOException {
        AmazonDynamoDBClient dbClient = new AmazonDynamoDBClient(AWSMobileClient
                .defaultMobileClient()
                .getIdentityManager()
                .getCredentialsProvider());
        final DynamoDBMapper mapper = new DynamoDBMapper(dbClient);

        mapper.save(newPin);
    }

    public static PinsDO createPinForTable(String photoId,Double latitude,Double longitude,String
            caption,String userId) {
        if (caption == null || photoId == null || photoId.equals("") || userId == null || userId.equals("")) {
            return null;
        }

        PinsDO pin = new PinsDO();
        pin.setLongitude(longitude);
        pin.setLatitude(latitude);
        pin.setCaption(caption);
        pin.setPhotoId(photoId);
        pin.setUserId(userId);

        return pin;
    }
}
