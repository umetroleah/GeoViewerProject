package com.cmsc355.thebestgroup.geoviewer.settings;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

import com.cmsc355.thebestgroup.geoviewer.R;

/*
 * Created by mroseberry on 11/25/16.
 *
 * Screen with links crediting the creators of the icons and logo used in the app.
 */

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView credit = (TextView) findViewById(R.id.iconCredit);
        credit.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
