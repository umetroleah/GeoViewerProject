package com.cmsc355.thebestgroup.geoviewer.viewphoto;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.widget.Toast;

import com.cmsc355.thebestgroup.geoviewer.R;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.AsyncPhotoDownloader;
import com.cmsc355.thebestgroup.geoviewer.databasefunctions.PhotoDownloaderResponse;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Activity for displaying a photo when we are near it / visiting it.
 * Activity is called from MapsActivity. Only available when near photos.
 * Implements a pager, which allows user to horizontally flip thru all photos nearby, with each
 *      photo in its own fragment.
 */
public class ViewPhotoActivity extends FragmentActivity {

    ViewPhotoPagerAdapter pagerAdapter;
    ViewPager photoViewPager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_photo);

        Intent intent = getIntent();

        //pageAdapter will help dynamically manage fragments within pager.
        //This constructor will handle creation of fragments, so we pass photo info/intent
        pagerAdapter = new ViewPhotoPagerAdapter(getSupportFragmentManager(), intent);
        photoViewPager = (ViewPager) findViewById(R.id.pager);
        photoViewPager.setAdapter(pagerAdapter);
    }

    //The PagerAdapter manages creation (sometimes dynamically) of fragments for our pager.
    public class ViewPhotoPagerAdapter extends FragmentStatePagerAdapter
            implements PhotoDownloaderResponse {

        private ArrayList<Fragment> photoFragmentList;
        private ArrayList<Bundle> photosPendingDownload;

        @Override
        public Fragment getItem(int index) {
            return photoFragmentList.get(index);
        }

        @Override
        public int getCount() {
            return photoFragmentList.size();
        }

        //In our case, we load all our photos in range at once, so constructor will create fragments
        public ViewPhotoPagerAdapter(FragmentManager fm, Intent intent) {
            super(fm);

            photoFragmentList = new ArrayList<Fragment>();
            photosPendingDownload = new ArrayList<Bundle>();

            //Pull data from intent
            String[] tags = intent.getStringArrayExtra("tags");
            double[] lats = intent.getDoubleArrayExtra("lats");
            double[] longs = intent.getDoubleArrayExtra("longs");

            for (int i = 0; i < tags.length; i++) {
                String photoTag = tags[i];

                String photoFile = null;
                try {
                    photoFile = createPhotoFile(photoTag);
                } catch (IOException ex) {
                    // Error occurred while creating the File
                    Context context = getApplicationContext();
                    CharSequence text = "Error. Try again.";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }

                if (photoFile != null) {    //Continue only if the File was successfully created
                    AsyncPhotoDownloader photoDownloader = new AsyncPhotoDownloader();
                    photoDownloader.delegate = this;
                    photoDownloader.execute(photoFile, photoTag);

                    Bundle bundle = new Bundle();
                    bundle.putDouble("lat", lats[i]);
                    bundle.putDouble("lon", longs[i]);
                    bundle.putString("tag", photoTag);
                    bundle.putString("filePath", photoFile);
                    photosPendingDownload.add(bundle);
                }
            }
        }

        private String createPhotoFile(String photoTag) throws IOException {
            // Create an image file name
            //String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String photoFileName = createFileName(photoTag);
            File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File photoFile = File.createTempFile(photoFileName, ".jpg", storageDir);

            // Save the file path
            return photoFile.getAbsolutePath();
        }

        public void photoDownloadFinished(String filePath) {
            if (filePath == null) {   //failed
                Context context = getApplicationContext();
                CharSequence text = "Error. Try again";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }

            Bundle bundle = null;
            for (Bundle current : photosPendingDownload) {
                if (current.getString("filePath").equals(filePath)) {
                    bundle = current;
                    break;
                }
            }
            photosPendingDownload.remove(bundle);

            bundle.putInt("photoNumber", getCount() + 1);

            ViewPhotoFragment newFrag = new ViewPhotoFragment();
            newFrag.setArguments(bundle);
            photoFragmentList.add(newFrag);

            notifyDataSetChanged(); //required by FragmentStatePagerAdapter
        }
    }

    public static String createFileName(String tag) {
        if (tag == null) {
            return null;
        } else if (tag == "") {
            return null;
        } else {
            return "JPEG_" + tag + "_";
        }
    }
}
