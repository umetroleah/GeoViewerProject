package com.cmsc355.thebestgroup.geoviewer.databasefunctions;

/*
 * Created by mroseberry on 10/11/16.
 *
 * Interface to assist getting data from AsyncPhotoDownloader
 */

public interface PhotoDownloaderResponse {
    void photoDownloadFinished(String result);
}
