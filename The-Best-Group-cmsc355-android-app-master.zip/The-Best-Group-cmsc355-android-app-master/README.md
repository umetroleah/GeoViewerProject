# The-Best-Group-cmsc355-android-app
cmsc355-android-app created for The-Best-Group

Iteration 3:

Iteration three includes the user stories Visit a photo, View app about page and Pan map manually.

With this iteration, users are now able to view photos posted by other users. Users can scroll through viewing all photos attached to pins visible on the phone's screen.

Additionally, several options were added to the settings screen of the phone. From the settings page, user can view an about page and click a switch to pan the map manually, rather than have it stay centered on the user as they move. Getting this to work required the use of Android's SharedPreferences, so that 2 activities can access the same data value. This took some trial and error, as the default values would change the switch, causing the switch to sometimes not work. After some trial and error, the default values stopped causing problems. 

Out main difficulties this iteration were related to downloading photos from our database and viewing them on the phone. We also had difficulties getting the geofences working, which we had started in previous iterations, so we stopped using them in favor of viewing all the photos visible on the screen. Lastly, we attempted to implement functionaility so that a user could view all the photos they had previously posted. We ran into difficulties downloaded these sets of photos from the database, and we unable to complete this fourth user story.

Our unit tests where difficult because we didn't do any local variable manipulation, that is, everything interacted with services. We ended up with 10 unit tests and put them in the unitTests folder (GeoViewer/app/src/androidTest/java/com/cmsc355/thebestgroup/geoviewer/unittests) 

Out tests are still tricky, and still likely to cause the failure to crunch error depending on the directory in which the project is placed. Please contact us and we will happily meet with you to run the tests.

As with previous iterations, try using coordinates 37.545353/-77.448633 (which should put you inside Engineering East Hall). You may have to run the app again after inputting these coordinates, if no coordinates were input previously. As with the last iteration, we ran checkstyle on our source code and test code but did not run checkstyle on the amazonaws library.

--------------------------------------------

Iteration 2: 
Iteration two includes the user stories Login, Logout, Captions, and a Database Iteration. These user stories represent new features, as well as improved implementations.

The database has a table now, rather than just storing the photo files in an amazon "bucket". This change allowed us to associate photos more efficiently with coordinates, as well as with users and captions. This change also allows us to more effectively download and display pins. Rather than downloading and displaying all pins, which presents scalability issues, the app now downloads only those pins near the user.

For simplicity, we implemented login so that users login with an existing Google account. The app loads on a splash screen and checks if the user has logged in previously without logging out. If so, the app proceeds directly to the map screen. If the user is not logged in, it loads a login screen and prompts the user to login with their Google account. We implemented these features with the help of our Amazon AWS library.

For captions, a field for a caption was added to the add photo screen, which is enabled after taking a photo. The field allows for only 140 characters. The caption is then submitted to the database with the photo. Now, the caption is available for eventual download and display in later iterations.

We had difficulties this iteration connecting the database and the login activity, which took time. After this, we also had trouble with testing our geofence feature in the emulator, as the emulator would not cause geofence events to fire. Because of these troubles and delays, we pushed the ViewPhotos user story, which we were planning on implementing this iteration, back to the third iteration. Still, we did make progress, and the geofencing and VisitPhotos code is nearly totally done, but untested, and is available in our repository.

Another difficulty for this user story was testing. The addition of user credentials caused most of our previous tests to break, as the new user stories now expected that the user was already logged in. We were unable to successfully stub or mock the database so that calls could be made to it without first logging in, but added in some workarounds to catch null pointers. However, two of our database tests pass, then crash the app, as the app is expecting valid credentials that aren't available in the tests.

Note: We ran checkstyle on our source code and our test code. But, we did not run checkstyle on the amazonaws library folder in our project, as it is code from a third party which we do not need to maintain.
 
Please keep the following in mind when running any tests related to login and logout:
- Some of the tests will require a user to be logged in to run. A Google login dialog box will pop-up, which must be interacted with for the tests to pass.
- These tests also require waiting for Google Sign-in. A wait period of 5000 ms is built into the test, but if the emulator is particularly slow, this time may need to be lengthened.
- TestNoInternet test requires that celluar data be turned off, which as far as we can tell cannot be done programmatically on the emulator. So celluar data much be turned off before running this test.
- TestPreviousLogin and TestSettingsLogout require that you be previously logged in on the emulator. 

The tests related to the maps require mock locations, which in turn require that the emulator be setup in advance as follows:
- In settings, go to About Phone (or About emulator), and click the build # until Developer Options turn on.
- Go back to settings, then to Developer Options, then scroll down and select GeoViewer as a mock location app.

If you have any trouble running any of the tests, please contact us.

As in the first iteration, try using coordinates 37.545353/-77.448633 (which should put you inside Engineering East Hall). You may have to run the app again after inputting these coordinates, if no coordinates were input previously. The failure to crunch issue which caused the test to not run at all last time is an issue with the length of file names, particularly those related to the GoogleAPI. This should be solvable moving the entire project to your root directory. However, if these problem persists please contact us.

--------------------------------------------
Iteration 1: 
Iteration one includes implementation of user stories to add a photo to the database, use the background service of uploading and downloading photos to the database and view a map centered on the user with the locations of the photos marked.

In this interation, a user should be able to view a map centered on them and view the locations of photos stored in the database (all sample data located near VCU - to change locations, expand the running emulator's option menu and enter in your desired lat/long, try 37.540725/-77.436048 for Richmond). The user should also be able to click the Add Photo button to start another Activity. On this Activity, the user can take a photo, then submit it to the database.

We had particular difficulty getting the Amazon Web Service database to work. This included adding the coordinates to the image file names, then parsing them out for later use, verses possibly just storing these values separately. It also involved using several Async tasks to retrieve results from the methods responsible our uploading and downloading. Our project has a AWSDemo in it for examples, which should be ignored and is neatly in its own folder.

We also had trouble getting the map to consistently work correctly on the emulator (we put in place several fixes to avoid null pointers) and with testing the map activities, particularly with the mock locations.

Due to these difficulties we were not able to complete the fourth user story we had originally planned for this iteration. It is near completion, and activites for geofencing and viewing photos are currently in our application.
